#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#define MAX_STRING_SIZE 20

///change the color of text
///form of using function is like this:
///textcolor(number of desired color)
typedef enum
{
    BLACK = 0, BLUE = 1, GREEN = 2,
    AQUA = 3,  RED = 4,  PURPLE = 5,
    YELLOW = 6, WHITE = 7, GRAY = 8,
    LIGHT_BLUE = 9, LIGHT_GREEN = 10,
    LIGHT_AQUA = 11, LIGHT_RED = 12,
    LIGHT_PURPLE = 13, LIGHT_YELLOW = 14,
    LIGHT_WHITE = 15
} ConsoleColors;
typedef HANDLE Handle;
typedef CONSOLE_SCREEN_BUFFER_INFO BufferInfo;
typedef WORD Word;
short textcolor(const ConsoleColors foreground)
{
    Handle consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    BufferInfo bufferInfo;
    if(!GetConsoleScreenBufferInfo(consoleHandle, &bufferInfo))
        return 0;
    Word color = (bufferInfo.wAttributes & 0xF0) + (foreground & 0x0F);
    SetConsoleTextAttribute(consoleHandle, color);
    return 1;
}
///end of color change function

//header of functions

char chget();
int signup();
void pass_check();
int signin();
void menu();
int account_check(char a);
void begin_level_timer(int number_of_level);
float calc_score(float t, float f, float level, float playtime);
void game();

char pause_menu();
int pause(float levelscore, int level_number);
void first_save(float levelscore2, int level_number);
void save(float levelscore3, int level_number);

//end of headers

char global_username[50];

//start main function

void main()
{
    menu();
    char s;
    s = chget();
    system("cls");
    system("color 57");

    //check if user have account or not

   int test_that_code_run_truly = account_check(s);
   if(test_that_code_run_truly == 1)
   {
       system("cls");
       game();
   }
   else
   {
       exit(0);
   }

}

//start functions except main

void menu()
{
        system("color 67");
    textcolor(13);
    printf("\n\n\n");
    printf("                                     =======                                    \n");
    printf("             //\\\\        //\\\\       ||         ||\\\\    ||   ||      ||       \n");
    printf("            //  \\\\      //  \\\\      ||         || \\\\   ||   ||      ||       \n");
    printf("           //    \\\\    //    \\\\     ||======   ||  \\\\  ||   ||      ||       \n");
    printf("          //      \\\\  //      \\\\    ||         ||   \\\\ ||   ||      ||        \n");
    printf("         //        \\\\//        \\\\   ||         ||    \\\\||   ||======||         \n");
    printf("                                     ========                                      \n");
    textcolor(7);
    printf("\n\n\n");
    printf("          for");
    textcolor(1);
    printf("     sign in  ");
    textcolor(7);
    printf("(if you have account already)please enter character");
    textcolor(1);
    printf("  'i' \n");
    textcolor(7);

    printf("\n\n\n");
    printf("           for");
    textcolor(1);
    printf("     sign up ");
    textcolor(7);
    printf("(if you don`t have account already)please enter character");
    textcolor(1);
    printf(" 'u'\n");
    textcolor(7);
    printf("\n\n\n\r");
    printf("goal of the game : \n");
    textcolor(4);
    printf("you need to quickly enter the words shown on the page on your keyboard\n");
    textcolor(7);
    printf("pointing out : ");
    textcolor(4);
    printf("when you arrival to game , your keyboard should be lowercase!!!");

}
//..............................................................................
char chget(void)
{
    char ch;
    ch = getch();
    ch = tolower(ch);
    switch(ch)
    {
        case 'i' :  return 'i';
        case 'u' :  return 'u';
        default :  system("cls");
                   textcolor(4);
                   printf("you entered wrong!!\n");
                   textcolor(9);
                   printf("\nenter 'i' for sign in\n");
                   printf("enter 'u' for sign up\n");
                   textcolor(7);
                   printf("\nplease try again\n");
                   chget();
    }
}
//..............................................................................
int account_check(char a)
{

    if(a == 'u')
    {
       int j = signup();
       if(j == 1)
        return 1;
    }
    if(a == 'i')
    {
       int d = signin();
       if(d == 1)
        return 1;
    }

}
//..............................................................................
void pass_check(char username[50])
{           /// this function used for password of sign in function
            FILE *password_file_ptr;
            password_file_ptr = fopen("password.txt", "a+");
            if(password_file_ptr == NULL)
            {
                system("cls");
                textcolor(4);
                printf("\ngame can`t load...");
                textcolor(7);
                Sleep(3000);
                exit(0);
            }
           FILE *name_file_ptr;
           name_file_ptr = fopen("user name.txt", "a+");
           if(name_file_ptr == NULL)
           {
                system("cls");
                textcolor(4);
                printf("\ngame can`t load...");
                textcolor(7);
                Sleep(3000);
                exit(0);
           }

            int j;
            int eof;
            char password[50];
            char file_password[50];
            char ch;
            int p=0;
            int flag = 0;

            // get password from user

            while(ch != 'y')
            {
                printf("enter the password : \n");
                do{
                    password[p]=getch();
                    if(password[p]!='\r')
                    {
                        textcolor(14);
                        printf("*");
                        textcolor(7);
                    }
                    p++;
                }while(password[p-1]!='\r');
                password[p-1]='\0';
                printf("\ndo you enter password true???(y/n)\n");
                ch = getch();
            }
            strcat(password, "\n");

           //search for entered password in file

           do{
                fgets(file_password, 50, password_file_ptr);
                j = strcmp(file_password, password);
                if(j == 0)
                    flag = 1;
                eof = feof(password_file_ptr);
           }while(eof == 0);
           if(flag == 1) // if flag == 1 , that mean the entered password is used before
           {
                textcolor(4);
                printf("this password is used , please enter another password :\n");
                textcolor(7);
                Sleep(3000);
                pass_check(username);
           }else
           {
             fputs(password, password_file_ptr);
             strcpy(global_username, username);
             fputs(username, name_file_ptr);
           }
}
//..............................................................................

int signup(void)
{
    FILE *name_file_ptr;
    name_file_ptr = fopen("user name.txt", "a+");
    if(name_file_ptr == NULL)
    {
        system("cls");
        textcolor(4);
        printf("\ngame can`t load...");
        textcolor(7);
        Sleep(3000);
        exit(0);
    }

    //get informations from user

    //get user name from user

    char user_name[50];
    char password[50];
    char file_names[50];
    char file_password[50];
    int i, eof;
    int flag = 0;
    printf("enter your <<user name>>:\n ");
    textcolor(14);
    gets(user_name);
    textcolor(7);
    strcat(user_name, "\n");

    //search for entered user name in file

    do{
        fgets(file_names, 80, name_file_ptr);
        i = strcmp(file_names, user_name);
        if(i == 0)
            flag = 1;
         eof = feof(name_file_ptr);
    }while(eof == 0);
    if(flag == 1)  // if flag == 1 that mean the entered user name is used before
    {
        textcolor(12);
        printf("this user name is used , please enter another user name!!!");
        Sleep(4000);
        textcolor(7);
        system("cls");
        signup();
    }
    else
    {
        fputs(user_name, name_file_ptr);
        pass_check(user_name);
    }

        return 1;  // this mean user can continue the game...
}
//..............................................................................
int signin(void)
{
    //opening files

    FILE *name_file_ptr;
    name_file_ptr = fopen("user name.txt", "r");
    FILE *password_file_ptr;
    password_file_ptr = fopen("password.txt", "r");

    //end of opening

    //get user name from user

    char user_name[50];
    char file_names[50];
    int i, eof;
    int flag = 0;
    printf("enter your user name:\n");
    textcolor(14);
    gets(user_name);
    textcolor(7);
    strcat(user_name, "\n");
    int line_counter = 0;
    //search for entered user name

    do{
        fgets(file_names, 80, name_file_ptr);
        line_counter++;
        i = strcmp(file_names, user_name);
        if(i == 0)
        {
            flag = 1;
            break;
        }
         eof = feof(name_file_ptr);
    }while(eof == 0);
    if(flag == 1)
    {
        char password[50];
        char file_password[50];
        int flag2 = 0;
        int j;

        //get password from user

        char ch;
        int p=0;
        while(ch != 'y')
        {
        printf("enter the password : \n");
        do{
         password[p]=getch();
         if(password[p]!='\r')
         {
            textcolor(14);
            printf("*");
            textcolor(7);
         }
        p++;
        }while(password[p-1]!='\r');
        password[p-1]='\0';
        printf("\ndo you enter password truly???(y/n)\n");
        ch = getch();
        }
         strcat(password, "\n");

        //search for entered password
        line_counter++;
        do{
        fgets(file_password, 50, password_file_ptr);
        line_counter--;
        if(line_counter == 1)
        {
            j = strcmp(file_password, password);
            if(j == 0)
            {
                flag2 = 1;
            }
            break;

        }
       }while(1);
       if(flag2 == 1)
       {
            strcpy(global_username, user_name);
            return 1;  // this mean that the user can continue the game...
       }else
        {
            textcolor(4);
            printf("you entered wrong!!!\n");
            printf("try again");
            textcolor(7);
            Sleep(2000);
            system("cls");
            signin();
        }
    }else
    {
        textcolor(12);
        printf("the user name not founded!!!\n");
        Sleep(2000);
        system("cls");
        textcolor(7);
        signin();
    }
}
//..............................................................................
char pause_menu()
{
    system("color 2E");
    system("cls");
    textcolor(7);
    printf("\n\n\n\t\tfor resume the game enter ");
    textcolor(3);
    printf(" '1' ");
    textcolor(7);
    printf("\n\n\t\tfor end the game and exit enter");
    textcolor(3);
    printf(" '2' ");
    char ch2 = getch();
    return ch2;
}
//..............................................................................
int pause(float levelscore, int level_number)
{
    system("cls");
    system("color 2E");
    float pausetime2;
    int pausetime;
    clock_t end2, start2 = clock();
    char ch = pause_menu();

    while(1)
    {
        switch(ch)
        {
            case '1' :
                end2 = clock();
                pausetime2 = (end2 - start2) / 1000.0;
                pausetime = round(pausetime2);
                return pausetime;
            case '2':
                exit(0);

            default :
               textcolor(4);
                printf("\nyou entered wrong!!!");
                printf("\ntry again : \n");
                textcolor(7);

        }
    }
}
//..............................................................................
void save(float levelscore3, int level_number)
{
        printf("\n\t\tdo you want to save the game? (y / n)");
        char a = getch();
        tolower(a);
        int length2;
        FILE *saver;
        switch(a)
        {
            case 'y' :
                saver = fopen(global_username, "a+");
                if(saver == NULL)
                {
                    printf("excuse me , game don`t save");
                    exit(0);
                }
                char l_n[50]; // level number
                itoa(level_number, l_n, 10);
                strcat(l_n, "\n");
                fputs(l_n, saver);

                char ch2[20];
                gcvt(levelscore3, 7, ch2);
                strcat(ch2, "\n");
                fputs(ch2, saver);

                exit(0);

            case 'n' :
                exit(0);

            default :
                textcolor(4);
                printf("\nyou enter wrong letter!!!");
                printf("\ntry again : ");
                save(levelscore3, level_number);
        }
        fclose(saver);

}
//..............................................................................
void continuee(int numberof_level, float scoreof_level)
{
        FILE *saver2;
        saver2 = fopen(global_username, "a+");

        if(saver2 == NULL)
        {
            printf("excuse me , game don`t save");
            exit(0);
        }
        char l_n2[50]; // level number
        itoa(numberof_level, l_n2, 10);
        strcat(l_n2, "\n");
        fputs(l_n2, saver2);
        char ch3[7];
        gcvt(scoreof_level, 7, ch3);
        strcat(ch3, "\n");
        fputs(ch3, saver2);
        fclose(saver2);
        printf("\nare2");
}
//..............................................................................
void begin_level_timer(int number_of_level)
{
    system("color 4A");
    for(int j = 9 ; j > 0 ; j--)
    {
        printf("\n\n\n\n\n\n\n\n\n\t\t\t level %d will start at  ", number_of_level);
        printf("\t");
        printf("*********\n");
        printf("\t\t\t\t\t\t\t");
        printf("*   %d   * \n", j);
        printf("\t\t\t\t\t\t\t");
        printf("*********");
        Sleep(1000);
        system("cls");
    }
    system("color 57");
}
//..............................................................................
float calc_score(float t, float f, float level, float playtime)
{
    float score = ((t * 2) - f) / playtime;
    float score2 = (level + 10) / 10;
    float mainscore = score * score2;
    return mainscore;
}
//..............................................................................
void game()
{
    int length = strlen(global_username);
    global_username[length - 1] = '\0';
    strcat(global_username, ".txt");
    char get_level_file[10];
    int counter = 1;
    int levelnumber = 0;
    int eof2;
    FILE *pt;
    pt = fopen(global_username, "r");
    if(pt == NULL)
    {
        fclose(pt);
        pt = fopen(global_username, "w");
        if(pt == NULL)
        {
            textcolor(4);
            printf("\nyou can`t continue the game...");
            exit(0);
        }
        fclose(pt);
    }
    else
    {
        do{
            fgets(get_level_file, 80, pt);
            if(counter % 2)
            {
               levelnumber = atoi(get_level_file);
            }
            counter++;
            eof2 = feof(pt);

        }while(eof2 == 0);
        fseek(pt, SEEK_SET, SEEK_CUR);
    }
    fclose(pt);
    if(levelnumber != NULL)
    {
        printf("do you want to continue the saved game?(y / n)");
        char b;
        b = getch();
        tolower(b);
        while(1)
        {
            switch(b)
            {
                case 'n' :
                    levelnumber = 0;
                    FILE *pf;
                    pf = fopen(global_username, "w");
                    fclose(pf);
                    break;
               case 'y' :
                    break;
               default :
                    continue;
            }
            if(b == 'y' || b == 'n')
                break;
        }
    }
    system("cls");
    system("color 57");
    int k;
    float k2;
    char ch[50];
    float false_letters;
    clock_t start, end;
    float duration2;
    float duration;
    float score_of_word[26];
    float score_of_level[12];

    for(int g = 1 ; g < 12 ; g++)
    {
        score_of_level[g] = 0;
    }

    char strainer;
    float level_number;

    for(level_number = (levelnumber + 1) ; level_number < 12 ; level_number++)
    {
        int ln = level_number - 1;
        if(level_number > (levelnumber + 1))
        {
            while(1)
            {
                system("cls");
                system("color 70");
                printf("\n\n\n\t\t");
                printf("do you want to continue the game?(y / n)");
                char way_decide = getch();
                tolower(way_decide);
                switch(way_decide)
                {
                    case 'y':
                        continuee(ln, score_of_level[ln]);
                        break;
                    case 'n':
                        save(score_of_level[ln], ln);
                    default:
                         continue;
                }
                if(way_decide == 'y')
                    break;
            }
        }
        system("cls");
        begin_level_timer(level_number);
        char *level[10];
        itoa(level_number, level, 10);
        strcat(level, ".txt");
	    srand(time(NULL));

        for(int i = 1 ; i < 26 ; i++)
        {
            /// i is the word number
	        int flag = 0;
	        char str[26][MAX_STRING_SIZE],pick[26][MAX_STRING_SIZE];
do{
            false_letters = 0;
            FILE *fp;
            int readCount = 0;
	        fp = fopen(level, "r");
            if(fp)
            {
		        if (fgets(pick[i], MAX_STRING_SIZE, fp) != NULL)
		        {
                    readCount = 1;
			        while(fgets(str[i], MAX_STRING_SIZE, fp) != NULL)
                    {
                        if ( (rand() % ++readCount)==0)
				        {
                            strcpy(pick[i], str[i]);
                        }
                    }
		        }
            }
            fclose(fp);


            strlwr(pick[i]);
            k = strlen(pick[i]);
            k2 = k;
            pick[i][k - 1] = '\0';
   	        /// check if the word is repeated or not
   	        flag = 0;
	        for(int c = (i - 1) ; c >= 1 ; c--)
            {
                int difference = strcmp(pick[i], pick[c]);
                if (difference == 0)
                {
                    flag = 1;
                }
            }
    }while(flag == 1);

           /// end of checking

            printf("\nif you want to pause the game enter");
            textcolor(11);
            printf(" '5' \n");
            textcolor(7);
            printf(".................\n");
            printf(".................\n");
            printf(".................\n");
            printf(".................\n");
            printf("%d", i);
            printf("\n====>>");
            textcolor(10);
            printf(" %s ", pick[i]);
            textcolor(7);
            printf("<<====");
            printf("\n       ");
            int pause_timer = 0;

	       ///get string from user and compare it with the main word

            start = clock();
            for(int j=0 ; j < k-1  ; j++)
            {
                strainer = getch();
                if(strainer == '5')
                {
                    pause_timer = pause(score_of_level[ln], ln);
                    system("color 57");
                    system("cls");
                    printf("\nif you want to pause the game enter");
                    textcolor(11);
                    printf(" '5' \n");
                    textcolor(7);
                    printf(".................\n");
                    printf(".................\n");
                    printf(".................\n");
                    printf(".................\n");
                    printf("%d", i);
                    printf("\n====>>");
                    textcolor(10);
                    printf(" %s ", pick[i]);
                    textcolor(7);
                    printf("<<====");
                    printf("\n       ");
                    for(int u = 0 ; u <= (j - 1) ;  u++)
                        printf("%c", ch[u]);
                    j--;
                }
                else
                {
                    ch[j] = strainer;
                    if(ch[j] == pick[i][j])
                    {
                        textcolor(9);
                        putch(ch[j]);
                        textcolor(7);
                    }
                    else
                    {
                        textcolor(4);
                        putch(ch[j]);
                        textcolor(7);
                        false_letters++;
                    }
                }
            }
            end = clock();
            duration2 = (end - start) / 1000.0;   /// mili second
            duration = round(duration2);          /// second
            duration -= pause_timer;

            ///calculating score

            score_of_word[i] = calc_score(k2 - 1, false_letters, level_number, duration);
            if(i == 25)
            {
                float sum = 0;
                for(int word_number = 1 ; word_number < 26 ; word_number++)
                {
                    sum += score_of_word[word_number];
                }
                score_of_level[ln + 1] = sum;
            }
            system("cls");
            }
            system("color 17");
            int level_number_show = level_number;
            textcolor(14);
            printf("\n\n\n\n\n\n\n\n\n\t\t\t");
            printf("score earned in level %d : ", level_number_show);
            textcolor(0);
            printf("%f", score_of_level[level_number_show]);
            textcolor(7);
            Sleep(10000);
            system("cls");
    }
    FILE *p;
    p = fopen(global_username, "r");
    if(p == NULL)
    {
        printf("\n file cant open");
        Sleep(20000);
        exit(0);
    }
    int counter2 = 0;
    char scorefile[10];
    int eof3;
    float sum2 = 0;
    do{
            counter2++;
            fgets(scorefile, 10, p);
            if((counter2 % 2) == 0)
            {
               float item = atof(scorefile);
               sum2 += item;
            }
            eof3 = feof(p);
    }while(eof3 == 0);
    printf("\ntotal score of levels is equal to = %f", sum2);
    printf("\n\n\n\t");
    textcolor(0);
    printf("press any key to continue...");
    textcolor(7);
    getch();

}






